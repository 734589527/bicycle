<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>�鿴��ά��</title>
</head>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="qrcode.js"></script>
<body>
    <style type="text/css">
       
        .log {
            position:absolute;  
            top:30%;            
            left:35%; 
            margin:-100px 0 0 -150px;     
            width:800px;                             
            height:800px;                           
            z-index:99;                           
            }
    </style>
    <input id="text" type="text" value="123" style="width:80% ; display:none" />
    <br><br> <br><br> <br><br> <br><br>
    <center>
<div id="qrcode" style="width:100px; height:100px;" class="log"></div>

<script type="text/javascript">
var qrcode = new QRCode(document.getElementById("qrcode"), {
	width : 600,
	height :600
});

function makeCode () {		
	var elText = document.getElementById("text");
	
	if (!elText.value) {
		alert("Input a text");
		elText.focus();
		return;
	}
	
	qrcode.makeCode("<?php echo $_GET['ad']; ?>");
}

makeCode();

$("#text").
	on("blur", function () {
		makeCode();
	}).
	on("keydown", function (e) {
		if (e.keyCode == 13) {
			makeCode();
		}
	});
</script>
<body>
</body>
</html>