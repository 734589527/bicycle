<?php
/*
    ���������� http://www.cnblogs.com/txw1958/
    CopyRight 2013 www.doucube.com  All Rights Reserved
*/
header('Content-type:text');

define("TOKEN", "weixin");

    
/*****************************************************access_token��ȡ��ʼ*****************************************/
$appid = "wxab732ce4074ec712";//��ȡaccess_token
$appsecret = "8009fab5c6064fe2668b2a26eb3cfa09";
$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$output = curl_exec($ch);
curl_close($ch);
$jsoninfo = json_decode($output, true);
$access_token = $jsoninfo["access_token"];
/*************************************************access_token��ȡ����**************************************************************/
//$access_token="FgXJoZyfPLoCRvC-jLpwnXwOh36xHtcvAj6XdZVALBkZKbEslzU39Sfri33ZQ9SA9TZmH9qaIdE_5M9ONSgiu3_JDxOjYKToD9lMh2pKtjP8H6gwe6AcIX62hqRfrPZpLAGjAAACRX";
/************************************�Զ���˵�������ʼ**********************************************************************/
$jsonmenu='
{
	"button":
	[
    	{
			"name":"��ѯ",
            "sub_button":
            [
            {
             	"type":"click",
                "name":"��ѯ�ճ�λ",
                "key":"1"
            },
            {
            	"type":"click",
                "name":"��ѯ�ҵ�ͣ����Ϣ",
                "key":"2"
            },
            {
            	"type":"click",
                "name":"��ѯ�ҵ�Ԥ��",
                "key":"3"
            }
            ]
		},
		
         {
			"name":"Ԥ��",
            "type":"click",
            "key":"4"  
		},
		{
			"name":"ͣ��",
            "type":"click",
            "key":"5"  
		}
      
		
	]
}';
$url="https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$access_token;
$result=https_request($url,$jsonmenu);
var_dump($result);
function https_request($url,$data=null)
{
    $curl=curl_init();
    curl_setopt($curl,CURLOPT_URL ,$url);
    curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,FALSE);
    if(!empty($data))
    {
        curl_setopt($curl,CURLOPT_POST,1);
        curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
    }
    curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
    $output=curl_exec($curl);
    curl_close($curl);
    return $output;
}
/*********************************�Զ���˵���������******************************************************************************/
$wechatObj = new wechatCallbackapiTest();
if (isset($_GET['echostr'])&&$_GET['echostr']!=123)
{
    
    $wechatObj->valid();
}
else
{
     $wechatObj->responseMsg();
    // $wechatObj->responseMsg();
}

class wechatCallbackapiTest
{
    public function valid()
    {
        $echoStr = $_GET["echostr"];
        if($this->checkSignature()){
            header('content-type:text');
            echo $echoStr;
            exit;
        }
    }

    private function checkSignature()
    {
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];

        $token = TOKEN;
        $tmpArr = array($token, $timestamp, $nonce);
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode( $tmpArr );
        $tmpStr = sha1( $tmpStr );

        if( $tmpStr == $signature ){
            return true;
        }else{
            return false;
        }
    }
    /*****************************���ݿ��ѯ��ʼ************************************************/
	
 private function sql($s)
{
         $a=0;
         $host = '3006c00a.nat123.net';
	$port = 25623;//mysql�˿ںţ�Ĭ��Ϊ3306���˴�Ϊ3307
	$user = '123';
	$pwd = '123';
    $connect = mysqli_connect('3006c00a.nat123.net','root','','bicket',25623) or die('Unale to connect'); 
	$result = mysqli_query($connect,$s); 
	while($row = mysqli_fetch_row($result))
    { 
	    $a=$row[0]; 
	} 
    return $a;
}
   
    /*************************************���ݿ��ѯ����****************************************************/
    /*************************************���ݿ��ѯ��ʼ***********************************************************/
    private function sqls($s)
{
    $a=0;
    $host = '3006c00a.nat123.net';
	$port = 25623;//mysql�˿ںţ�Ĭ��Ϊ3306���˴�Ϊ3307
	$user = '123';
	$pwd = '123';
    $connect = mysqli_connect('3006c00a.nat123.net','root','','bicket',25623) or die('Unale to connect'); 
	$result = mysqli_query($connect,$s); 
	while($row = mysqli_fetch_row($result))
    { 
	$a=$row[0]; 
	} 
    return $result;
}
    
    
    /*************************************���ݿ�д�� Ԥ����ʼ***************************************************/
  private function yd()
    {
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        if (!empty($postStr))
        {
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $fromUsername = $postObj->FromUserName;
            $toUsername = $postObj->ToUserName;
            $keyword = trim($postObj->Content);
            $key=$postObj->EventKey;
            $time = date('y-m-d H:i:s',time());
        }
        $a=0;
        $b=0;
        $host = '3006c00a.nat123.net';
	    $port = 25623;//mysql�˿ںţ�Ĭ��Ϊ3306���˴�Ϊ3307
	    $user = '123';
	    $pwd = '123';
        $connect = mysqli_connect('3006c00a.nat123.net','root','','bicket',25623) or die('Unale to connect'); 
        $sql = "select * from cj"; //where zt = '����'"; 
		$result = mysqli_query($connect,$sql);  
		while($row = mysqli_fetch_row($result))
    	{ 
        
            if($row[1]=="����") 
            {
              	$b=$row[0];
           	 	$a=1;
                break;
            }
		} 
         if($a==1)
        {
             $sql = "update  cj  set zt = 'Ԥ��' where zt = '����'and cj = '$b' "; 
             $sql1="insert into parking values ('$fromUsername','$time','$b','Ԥ��','')";
        }
        $result = mysqli_query($connect,$sql); 
        $result = mysqli_query($connect,$sql1); 
        return $b;
    }
    /*************************************���ݿ�д�� Ԥ������*********************************************/
    /*************************************��ȡ΢�ź�******************************************************/
    private function weixin()
    {
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        if (!empty($postStr))
        {
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $fromUsername = $postObj->FromUserName;
            $toUsername = $postObj->ToUserName;
            $keyword = trim($postObj->Content);
            $key=$postObj->EventKey;
            $time = date('y-m-d h:i:s',time());
        }
        return $fromUsername;
        
    }
    /**************************************��ά��****************************************/
    private function qrcode($s)
    {
       $qrcode = '{"action_name":"QR_LIMIT_SCENE","action_info":{"scene":{"scene_id":1000}}}';
        $url="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_tocken=$access_tocken";
        $result = self::https_request($url,$qrcode);
        $jsoninfo = json_decode($result,true);
        $ticket=$jsoninfo["ticket"];
       
        return $ticket;
    }
     function https_request($url,$data=null)
        {
           $curl=curl_init();
            curl_setopt($curl,CURLOPT_URL,$url);
            curl_setopt($curl,CURLOPT_SSL_VERIFYPERE,FALSE);
            curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,FALSE);
            {
                curl_setopt($curl,CURLOPT_POST,1);
                curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
            }
            curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
            $output = curl_exec($curl);
            curl_close($curl);
            return $output;
        }
    /*************************************ͣ����ʼ**********************************************************/
     private function tc()
    {
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        if (!empty($postStr))
        {
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $fromUsername = $postObj->FromUserName;
            $toUsername = $postObj->ToUserName;
            $keyword = trim($postObj->Content);
            $key=$postObj->EventKey;
            $time = date('y-m-d H:i:s',time());
        }
        $a=0;
        $host = '3006c00a.nat123.net';
	    $port = 25623;//mysql�˿ںţ�Ĭ��Ϊ3306���˴�Ϊ3307
	    $user = '123';
	    $pwd = '123';
        $connect = mysqli_connect('3006c00a.nat123.net','root','','bicket',25623) or die('Unale to connect'); 
        $sql = "select * from parking";
        $result = mysqli_query($connect,$sql); 
		while($row = mysqli_fetch_row($result))
    	{ 
        
            if($row[0]==$fromUsername&&$row[3]=="Ԥ��") 
            {
              	$b=$row[2];
           	 	$a=1;
                break;
            }
		}
        if($a==1)
        {
            
             $sql = "update parking set date1='$time' ,zt='ͣ����'  where users = '$fromUsername' and  cj='$b'";
             $result = mysqli_query($connect,$sql); 
            $sql1="update cj set zt = 'ͣ����' where cj = '$b'";
            $result = mysqli_query($connect,$sql1); 
             $s=$fromUsername.$b.rand(100,999);
             $sql = "update parking set qrcode = '$s' where users = '$fromUsername' and cj = '$b'";
             $result = mysqli_query($connect,$sql); 
             $a=$s;
         }
         return $a;
         
    }
    function create_erweima($content, $size = '300', $lev = 'L', $margin= '0') 
    {
	$content = urlencode($content);
	$image =' <img src="http://chart.apis.google.com/chart?chs='.$size.'x'.$size.'&amp;cht=qr&chld='.$lev.'|'.$margin.'&amp;chl='.$content.'"  widht="'.$size.'" height="'.$size.'" />';
	return $image;
}
    /**************************************ͣ������***********************************************************/
    /*************************************�Զ��ظ�**************************************************************/
   public function responseMsg()
    {
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

        if (!empty($postStr))
        {
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $fromUsername = $postObj->FromUserName;
            $toUsername = $postObj->ToUserName;
            $keyword = trim($postObj->Content);
            $key=$postObj->EventKey;
            $time = time();
        
            $textTpl = "<xml>
                        <ToUserName><![CDATA[%s]]></ToUserName>
                        <FromUserName><![CDATA[%s]]></FromUserName>
                        <CreateTime>%s</CreateTime>
                        <MsgType><![CDATA[%s]]></MsgType>
                        <Content><![CDATA[%s]]></Content>
                        <FuncFlag>0</FuncFlag>
                        </xml>";
              $textTpl1 = "<xml>
                        <ToUserName><![CDATA[%s]]></ToUserName>
                        <FromUserName><![CDATA[%s]]></FromUserName>
                        <CreateTime>%s</CreateTime>
                        <MsgType><![CDATA[image]]></MsgType>
                        <Image>
                        <MediaId><![CDATA[%s]]></MediaId>
                        </Image>
                        </xml>";
        
            if($key=="1")
            {
            	$msgType = "text";
                $sql = "select * from cj where zt = '����'"; 
                $sql1="select * from parking where users = '$fromUsername' and zt = 'Ԥ��'";
            	if(self::sql($sql)!="0")
           		{
                    if(self::sql($sql1)=="0")
                    {
					$contentStr ="�пճ�λ����Ԥ��" ;
                    }
                    else
                    {
                        $contentStr ="���Ѿ�Ԥ�������г�λ������ͣ��" ;
                    }
           		 }
            	else 
          	 	{
                	$contentStr ="�޿ճ�λ" ;
            	}
            	$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
				echo $resultStr;
            }
            else if($key=="2")
            {
                $msgType = "text";
                $sql = "select * from parking where users ='$fromUsername' and zt = 'ͣ��' or zt = 'ͣ����'";
    			 $connect = mysqli_connect('3006c00a.nat123.net','root','','bicket',25623) or die('Unale to connect'); 
				$result = mysqli_query($connect,$sql); 
                $content="";
            	if(self::sql($sql)!="0")
           		{
                    
                      while($row = mysqli_fetch_row($result))
    				{ 
        
           			 
              			$num=$row[2];
           	 			$arrive=$row[1];
        	    	   $contentStr =$contentStr. "��  λ  �ţ�  $num\n����ʱ�䣺     $arrive\n" ;
					} 
                   
           		 }
            	else 
          	 	{
                	$contentStr ="������ͣ������" ;
            	}
            	$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
				echo $resultStr;
            }
              else if($key=="3")
            {
                $msgType = "text";
                $sql = "select * from parking where zt = 'Ԥ��' and users ='$fromUsername' ";
    			$connect = mysqli_connect('3006c00a.nat123.net','root','','bicket',25623) or die('Unale to connect'); 
				$result = mysqli_query($connect,$sql); 
            	if(self::sql($sql)!="0")
           		{
                      while($row = mysqli_fetch_row($result))
    				{ 
        
           			 
              			$num=$row[2];
           	 			$arrive=$row[1];
                		break;
        	    	
					} 
                    $contentStr = "��  λ  �ţ�  $num\n Ԥ��ʱ�䣺     $arrive" ;
           		 }
            	else 
          	 	{
                	$contentStr ="����Ԥ������" ;
            	}
            	$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
				echo $resultStr;
            }
             else if($key=="4")
            {
                $msgType="text";
                 $s="select * from parking where users = '$fromUsername' and zt = 'Ԥ��'  ";
                 $a=self::sql($s);
                 if($a=="0")
                 {
                     $b=self::yd();
                	 if($b==0)
                	{
                    	$contentStr="�޿ճ�λ,����Ԥ��";
                	}
                
               	 	else
               		 {
                    	$contentStr="Ԥ���ɹ�,��Ԥ���ĳ�λ��Ϊ  $b,�뽫���г�������ͣ���ܺ���ͣ����15����δͣ���Զ�ȡ��Ԥ����";
                	}
                 }
                 else
                 {
                     $contentStr="���Ѿ�Ԥ�������г�λ������ͣ��";
                 }
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
				echo $resultStr;
            }
             else if($key=="5")
            {
                $msgType="text";
                $s="select * from parking where users = '$fromUsername'and zt = 'Ԥ��'";
                 if(self::sql($s)!="0")
                 {
                     $a=self::tc();
                     $contentStr="������Ӳ鿴ȡ����ά��\nhttp://1.zixingchejia.applinzi.com/qrcode.php?ad=$a";
                 }
                 else
                 {
                     $contentStr="����Ԥ�����г���";
                 }
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
				echo $resultStr;
            }
        }
        else
        {
            echo "";
            exit;
        }
   }    
}
    ?>