﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using 进销存;

namespace bicket
{
    public partial class Form1 : Form
    {
        String sqls = "Database=bicket;Data Source=localhost;User Id=root;Password=;CharSet=utf8;port=3306;";
        MySqlConnection sqlcon_cjgl = null;
        MySqlConnection sqlcon_cjzs = null;
        MySqlConnection sqlcon_tc = null;
        MySqlConnection sqlcon_tc1 = null;
        MySqlConnection sqlcon_qc = null;
        MySqlConnection sqlcon_qc1 = null;
        MySqlConnection sqlcon_ydjs = null;
        MySqlConnection sqlcon_ydjs1 = null;
        MySqlConnection sqlcon_cjck = null;
        MySqlConnection sqlcon_rzck = null;

        Thread th = null;
        Thread th2 = null;
        Thread th3 = null;
        String name;
        int time;
        public Form1()
        {

            InitializeComponent();
            //this.panel2.Controls.Clear();
          //  f = new Form2();
            this.skinEngine1.SkinFile = "SteelBlack.ssk";
            try
            {
                sqlcon_cjgl = new MySqlConnection(sqls);
                sqlcon_cjzs = new MySqlConnection(sqls);
                sqlcon_tc = new MySqlConnection(sqls);
                sqlcon_tc1 = new MySqlConnection(sqls);
                sqlcon_qc = new MySqlConnection(sqls);
                sqlcon_qc1 = new MySqlConnection(sqls);
                sqlcon_rzck = new MySqlConnection(sqls);
                sqlcon_ydjs = new MySqlConnection(sqls);
                sqlcon_ydjs1 = new MySqlConnection(sqls);
                sqlcon_cjck = new MySqlConnection(sqls);
                /*sqlCons = new MySqlConnection("Database=bicket;Data Source=localhost;User Id=root;Password=;pooling=false;CharSet=utf8;port=3306;");
                
                //3006c00a.nat123.net 25623
                sqlCon = new MySqlConnection("Database=bicket;Data Source=localhost;User Id=root;Password=;pooling=false;CharSet=utf8;port=3306;");
                sqlCon.Open();

                sqlCon2 = new MySqlConnection("Database=bicket;Data Source=localhost;User Id=root;Password=;pooling=false;CharSet=utf8;port=3306;");
                sqlCon3 = new MySqlConnection("Database=bicket;Data Source=localhost;User Id=root;Password=;pooling=false;CharSet=utf8;port=3306;");
                //sqlCon2.Open();
                sqlCon4 = new MySqlConnection("Database=bicket;Data Source=localhost;User Id=root;Password=;pooling=false;CharSet=utf8;port=3306;");
                sqlCon5 = new MySqlConnection("Database=bicket;Data Source=localhost;User Id=root;Password=;pooling=false;CharSet=utf8;port=3306;");
                sqlCon6 = new MySqlConnection("Database=bicket;Data Source=localhost;User Id=root;Password=;pooling=false;CharSet=utf8;port=3306;");
                sqlCon7 = new MySqlConnection("Database=bicket;Data Source=localhost;User Id=root;Password=;pooling=false;CharSet=utf8;port=3306;");
                sqlCon4.Open();
                sqlCon5.Open();
                sqlCon6.Open();*/
                MessageBox.Show("数据库连接成功");
                
            }
            catch
            {
                MessageBox.Show("数据库连接失败");
            }
            
            
            th = new Thread(new ThreadStart(th1));
            th2 = new Thread(new ThreadStart(ser2));
            th3 = new Thread(new ThreadStart(th3_));
            th.Start();
            th2.Start();
            th3.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.panel2.Controls.Clear();
            this.panel2.Controls.Add(this.panel1);
            update1();
        }
        public void update1()
        {
            sqlcon_cjgl.Open();
            this.comboBox1.Items.Clear();
            this.comboBox3.Items.Clear();
            this.comboBox2.Items.Clear();
            this.comboBox1.Text = "请选择自行车架";
            this.comboBox3.Text = "请选择自行车架";
            MySqlCommand cmd = new MySqlCommand("select * from cj ", sqlcon_cjgl);
            MySqlDataReader readerx = null;
            try
            {
                
                //MessageBox.Show("1");
                //打开连接
                // sqlCon.Open();
                //执行查询，并将结果返回给读取器
                readerx = cmd.ExecuteReader();
                while (readerx.Read())
                {
                    this.comboBox1.Items.Add(readerx[0].ToString());
                    this.comboBox3.Items.Add(readerx[0].ToString());
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("数据库连接错误，代码1");
            }
            finally
            {
                readerx.Close();
                sqlcon_cjgl.Close();
                
            }
            this.comboBox2.Items.Add("可用");
            this.comboBox2.Items.Add("报修");
            this.comboBox2.Text = "请选择车架状态";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (this.comboBox1.Text != "请选择自行车架" && this.comboBox2.Text != "请选择车架状态")
            {
                try
                {
                    sqlcon_cjzs.Open();
                    MySqlCommand cmd = new MySqlCommand("update cj set zt = '" + this.comboBox2.Text + "' where cj = '" + this.comboBox1.Text + "'", sqlcon_cjzs);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("更改成功");
                }
                catch
                {
                    MessageBox.Show("数据库连接失败，错误代码2");
                }
                finally 
                {
                    sqlcon_cjzs.Close();
                }
            }
        }
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                sqlcon_cjzs.Open();
                if (this.comboBox3.Text != "请选择自行车架")
                {
                    MySqlCommand cmd = new MySqlCommand("delete from cj  where cj = '" + this.comboBox3.Text + "'", sqlcon_cjzs);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("删除" + this.comboBox3.Text + "号车架成功");
                update1();
            }
            catch
            {
                MessageBox.Show("数据库连接失败，错误代码03");
            }
            finally 
            {
                sqlcon_cjzs.Close();
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                sqlcon_cjzs.Open();
                int num = this.comboBox3.Items.Count;
                String s = "";
                if (num < 9)
                {
                    s = "0" + (num + 1).ToString();
                }
                else
                    s = (num + 1).ToString();
                MySqlCommand cmd = new MySqlCommand("insert into cj values ('" + s + "','可用')", sqlcon_cjzs);
                cmd.ExecuteNonQuery();
                MessageBox.Show("增加车架成功，车架号为" + s);
                update1();
            }
            catch
            {
                MessageBox.Show("数据库连接失败，错误代码5");
            }
            finally
            { 
                sqlcon_cjzs.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlDataReader reader = null;
            list l = new list();
            String[] s = new string[5] { "用户ID", "停车/预定时间", "车架", "状态", "二维码" };
            List<String>[] li = new List<string>[5];
            try
            {
                sqlcon_cjzs.Open();
          
            for (int i = 0; i < 5; i++)
            {
                li[i] = new List<string>();
            }
            MySqlCommand cmd = new MySqlCommand("select * from parking ", sqlcon_cjzs);
           
           

                //MessageBox.Show("1");
                //打开连接
                // sqlCon.Open();
                //执行查询，并将结果返回给读取器
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    li[0].Add(reader[0].ToString());
                    li[1].Add(reader[1].ToString());
                    li[2].Add(reader[2].ToString());
                    li[3].Add(reader[3].ToString());
                    li[4].Add(reader[4].ToString());
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("数据库连接失败，错误代码9");
            }
            finally
            {
                reader.Close();
                sqlcon_cjzs.Close();
            }
            l.SetBounds(0, 0, 665, 192);
            panel2.Controls.Clear();
            panel2.Size = new System.Drawing.Size(665, 300);
            panel2.Controls.Add(l);
            l.add(s);
            l.set(li);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MySqlDataReader reader = null;
            list l = new list();
            String[] s = new string[4] { "用户ID", "停车时间", "取车时间", "车架" };
            List<String>[] li = new List<string>[4];
            try
            {
                sqlcon_rzck.Open();
           
            for (int i = 0; i < 4; i++)
            {
                li[i] = new List<string>();
            }
            MySqlCommand cmd = new MySqlCommand("select * from log ",sqlcon_rzck);
            
            

                //MessageBox.Show("1");
                //打开连接
                // sqlCon.Open();
                //执行查询，并将结果返回给读取器
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    li[0].Add(reader[0].ToString());
                    li[1].Add(reader[1].ToString());
                    li[2].Add(reader[2].ToString());
                    li[3].Add(reader[3].ToString());
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("数据库连接失败，错误代码10");
            }
            finally
            {
                reader.Close();
                sqlcon_rzck.Close();
            }
            l.SetBounds(0, 0, 665, 192);
            panel2.Controls.Clear();
            panel2.Size = new System.Drawing.Size(665, 300);
            panel2.Controls.Add(l);
            l.add(s);
            l.set(li);
        }
        public void th1()
        {
            MySqlDataReader readers1x = null;
             for(;;)
            {
              
                try
                {
                    sqlcon_tc.Open();
                    sqlcon_tc1.Open();
                    MySqlCommand cmd;

                    String cj = "";
                   
                    cmd = new MySqlCommand("select * from parking ", sqlcon_tc);


                    //MessageBox.Show("1");
                    //打开连接
                    //    sqlCon.Open();
                    //执行查询，并将结果返回给读取器
                    readers1x = cmd.ExecuteReader();
                    while (readers1x.Read())
                    {
                        if (readers1x[3].ToString() == "停车中")
                        {
                           
                            cj = readers1x[2].ToString();
                            ser1("2");
                            MySqlCommand cmdx = new MySqlCommand("update parking set zt = '停车' where cj = '" + cj + "'",sqlcon_tc1);
                            cmdx.ExecuteNonQuery();  
                            MySqlCommand cmdz = new MySqlCommand("update cj set zt = '停车' where cj = '" + cj + "'", sqlcon_tc1);
                            cmdz.ExecuteNonQuery();
                            name = cj + "号停车架正在停车";
                            time = 10;
                            MethodInvoker mi = new MethodInvoker(ax);
                            BeginInvoke(mi);
                          
                        }
                    }
                    readers1x.Close();
                   
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    MessageBox.Show("数据库连接失败，错误代码6");
                }
            finally
            {
               ;
                sqlcon_tc.Close();
                sqlcon_tc1.Close();
                Thread.Sleep(100);
            }
            
        }
            
        }
        
        public void ser2()
        {
            try
            {
             int recv;//用于表示客户端发送的信息长度
            byte[] data=new byte[1024];//用于缓存客户端所发送的信息,通过socket传递的信息必须为字节数组
            IPEndPoint ipep=new IPEndPoint(IPAddress.Any,9700);//本机预使用的IP和端口
            Socket newsock=new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
            newsock.Bind(ipep);//绑定
            newsock.Listen(10);//监听
            Console.WriteLine("waiting for a client");
            Socket client=newsock.Accept();//当有可用的客户端连接尝试时执行，并返回一个新的socket,用于与客户端之间的通信
            IPEndPoint clientip=(IPEndPoint)client.RemoteEndPoint;
            while (true)
            {//用死循环来不断的从客户端获取信息
                data = new byte[1024];
                recv = client.Receive(data);
                MessageBox.Show("recv=" + recv);
                Console.WriteLine("recv=" + recv);
               /* while (recv != 0)//当信息长度为0，说明客户端连接断开
                {
                    ser2();
                    break;
                }*/
                  
                
                
                String s = Encoding.ASCII.GetString(data, 0, recv);
                MessageBox.Show(s);
                qc(s);
                client.Send(data, recv, SocketFlags.None);
                data = new byte[1024];
               
            }
            Console.WriteLine("Disconnected from" + clientip.Address);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show("5");
            }
        }
        public void ser1(String s)
        {
            try
            {
           // s = "1";
            byte[] sendData = System.Text.Encoding.Default.GetBytes(s);
            byte[] byteReceive = null;
            String ip = "192.168.191.2";
            int port = 9800;
                IPEndPoint remoteEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socket.Connect(IPAddress.Parse(ip), port);
                socket.Send(sendData);
              /* int count, size = 512;
                byte[] data = new byte[size];
                MemoryStream ms = new MemoryStream();
                while (0 != (count = socket.Receive(data, size, SocketFlags.None)))
                    ms.Write(data, 0, count);
                byteReceive = ms.ToArray();
                ms.Close();*/
                //方法2  
                //int bytes = 0;  
                //MemoryStream ms = new MemoryStream();  
                //while (true)  
                //{  
                //    byte[] byteMessage = new byte[10];  
                //    bytes = socket.Receive(byteMessage, byteMessage.Length, 0);  
                //    if (bytes <= 0)  
                //        break;  
                //    ms.Write(byteMessage, 0, bytes);  
                //}  
                //byteReceive = ms.ToArray();  
                //ms.Close();  

               socket.Shutdown(SocketShutdown.Both);
                socket.Close();
                MessageBox.Show("发送成功");
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
             

        }
        Form2 f;
        public void qc(String s)
        {
            MySqlDataReader reader = null;
            try
            {
                
                sqlcon_qc.Open();
                sqlcon_qc1.Open();
                MySqlCommand cmd = new MySqlCommand("select * from parking ", sqlcon_qc);
                
                String a="";
            

                //MessageBox.Show("1");
                //打开连接
                // sqlCon.Open();
                //执行查询，并将结果返回给读取器
                reader = cmd.ExecuteReader();
               
                while (reader.Read())
                {
                    if (s.Replace(" ", "").ToString().Contains(reader[4].ToString()))
                    {
                        
                        a = reader[2].ToString();
                        MySqlCommand cmd1 = new MySqlCommand("delete from parking where cj = '" + a + "'", sqlcon_qc1);
                        cmd1.ExecuteNonQuery();
                        MySqlCommand cmd2 = new MySqlCommand("update cj set zt = '可用' where cj = '" + a + "'", sqlcon_qc1);
                        cmd2.ExecuteNonQuery();
                        MySqlCommand cmd3 = new MySqlCommand("insert into log values ('" + reader[0].ToString() + "','" + reader[1].ToString() + "','" + DateTime.Now.ToString() + "','" + a + "')", sqlcon_qc1);
                        cmd3.ExecuteNonQuery();
                        name = a + "号停车架正在取车";
                        time = 10;
                        MethodInvoker mi = new MethodInvoker(ax);
                        BeginInvoke(mi);  
                        ser1(a + "d");
                        ser1("3");
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("数据库连接失败，错误代码7");
            }
            finally
            {
                reader.Close();
                sqlcon_qc.Close();
                sqlcon_qc1.Close();
            }
 
        }
        public void ax()
        {
           Form2 f1 = new Form2();
           f1.a(name, time);
        }
        public void th3_()
        {
            
            for (; ; )
            {
                MySqlDataReader reader = null;
                try
                {
                    sqlcon_ydjs.Open();
                    sqlcon_ydjs1.Open();
                //sqlCon.Open();
                MySqlCommand cmd = new MySqlCommand("select * from parking ", sqlcon_ydjs);

                
               


                    //MessageBox.Show("1");
                    //打开连接
                    // sqlCon.Open();
                    //执行查询，并将结果返回给读取器
                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        DateTime dt = Convert.ToDateTime(reader[1].ToString());
                        TimeSpan ts = new TimeSpan();
                        ts = DateTime.Now.Subtract(dt).Duration();
                       if (ts.TotalSeconds >= 15*60&&reader[3].ToString()=="预定")
                        {
                            String a;
                            a = reader[2].ToString();
                            MySqlCommand cmd1 = new MySqlCommand("delete from parking where cj = '" + a + "'", sqlcon_ydjs1);
                            cmd1.ExecuteNonQuery();
                            MySqlCommand cmd2 = new MySqlCommand("update cj set zt = '可用' where cj = '" + a + "'", sqlcon_ydjs1);
                            cmd2.ExecuteNonQuery();
                        }
                        
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    MessageBox.Show("数据库连接失败，错误代码8");
                }
                finally
                {
                    reader.Close();
                    sqlcon_ydjs.Close();
                    sqlcon_ydjs1.Close();
                }
            }
        }
    }
}
