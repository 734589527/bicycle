﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Diagnostics;

namespace 进销存
{
    public partial class list : Panel
    {
       public ListView lv = new ListView();
       int sum = 1, num = 1, numx = 0, dnum = 4, numd = 0, sumd = 0 ,its=0,itc=0;
       public Panel pan = new Panel();
       public Button up = new Button();
       public Button down = new Button();
       public Label suml = new Label();
       public TextBox tex = new TextBox();
       public Button but = new Button();
       List<String>[] listss;
       ListViewItem item = new ListViewItem();
        String[][] s=new string[100][];
        Button pr = new Button();
        public ListView z = new ListView();
        ListViewItem zitem = new ListViewItem();
        public list()
        {
            lv.Clear();
            lv = new ListView();
            z = new ListView();
            InitializeComponent();
            this.Controls.Add(lv);
            pan.SetBounds(-220, 130, 1200, 40);
            lv.HeaderStyle = ColumnHeaderStyle.Clickable;
            lv.BorderStyle = BorderStyle;
            lv.GridLines = true;
            //lv.OwnerDraw = true;
            lv.View = View.List;
            lv.View = View.Details;
            lv.SetBounds(0, 0, 660, 130);
            lv.Font = new Font("宋体", 14);
            lv.BackColor = Color.DimGray;
            this.Controls.Add(pan);
            pan.Size = new System.Drawing.Size(1200,40);
            pan.BackColor = Color.White;
            up.Text = "上一页";
            up.SetBounds(270, 5, 70, 30);
            up.FlatStyle = FlatStyle.Popup;
            pan.Controls.Add(up);
            tex.SetBounds(400, 5, 40, 30);
            pan.Controls.Add(tex);
            tex.Text = num.ToString();
            suml.SetBounds(445, 5, 60, 30);
            pr.Text = "打印";
            pr.SetBounds(760, 5, 70, 30);
            pr.FlatStyle = FlatStyle.Popup;
            pan.Controls.Add(pr);
            pan.Controls.Add(suml);
            suml.Font = new Font("宋体", 14);
            tex.Font = new Font("宋体", 14);
            down.Text = "下一页";
            down.SetBounds(535, 5, 70, 30);
            down.FlatStyle = FlatStyle.Popup;
            pan.Controls.Add(down);
            but.Text = "跳转";
            but.SetBounds(650, 5, 70, 30);
            but.FlatStyle = FlatStyle.Popup;
            pan.Controls.Add(but);
            suml.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            up.Click += new EventHandler(up_click);
            down.Click += new EventHandler(down_click);
            but.Click += new EventHandler(bnt_click);
            for (int i = 0; i < 100; i++)
            {
                s[i] = new string[10000];
               
            }
            lv.Columns.Add("", 45, HorizontalAlignment.Left);
            z.Columns.Add("", 30, HorizontalAlignment.Left);
            lv.FullRowSelect = true;
        }
        public void add(String[] s)
        {
           // lv.Columns.Add(" ", 20, HorizontalAlignment.Left);
            for (int i = 0; i < s.Length; i++)
            {
                lv.Columns.Add(s[i], 120, HorizontalAlignment.Left);
                z.Columns.Add(s[i], 120, HorizontalAlignment.Left);
            }

           
        }
        public void set(List<String>[] list1)
        {
            listss = list1;
            sumd = list1[0].ToArray().Length;
            sum = sumd / dnum+1;
            its = list1[0].ToArray().Length;
            itc = list1.Length;
            suml.Text = "/" + sum.ToString();
            it(list1);
            data();
           
        }
        public void summ(List<string> list1)
        {
            sum = list1.ToArray().Length;
            numx = sum / dnum + 1;
        }
        private void up_click(object sender, EventArgs e)
        {
            if (num != 1)
            {
                
                lv.Items.Clear();
                num = num - 1;
                tex.Text = num.ToString();
                numd = numd - 4;
                data();
            }
        }
        private void down_click(object sender, EventArgs e)
        {
            if (num != sum)
            {
                
                lv.Items.Clear();
                num = num + 1;
                tex.Text = num.ToString();
                numd = numd + 4;
                data();
            }
        }
        private void bnt_click(object sender, EventArgs e)
        {
            if (int.Parse(tex.Text) <= sum)
            {
                lv.Items.Clear();
                num = int.Parse(tex.Text);
                tex.Text = num.ToString();
                numd = (int.Parse(tex.Text)-1) * 4;
                data();
            }
            else
            {
                tex.Text = num.ToString();
            }
        }
        public void it(List<String>[] lists)
        {
            for (int i = 0; i < lists.Length; i++)
            {
                s[i] = new string[10000];
                s[i] = lists[i].ToArray();
            }
        }

        private void data()
        {
            if (its > numd + 4)
            {
                int j = numd;
                for (;j<4;j++)
                {
                    item = new ListViewItem();
                    for (int k = 0; k < its; k++)
                    {
                        item.SubItems.Add(s[k][j]);
                    }
                    lv.Items.Add(item);
                }
            }
            else
            {
                int i = numd;

                for (; i <its ; i++)
                {
                    item = new ListViewItem();
                    for (int k = 0; k <itc ; k++)
                    {
                        item.SubItems.Add(s[k][i]);

                    } 
                    lv.Items.Add(item);
                }
            }
            z.Items.Clear();
            for (int z1 = 0; z1 < sumd; z1++)
            {
                zitem = new System.Windows.Forms.ListViewItem();
                for (int z2 = 0; z2 < itc; z2++)
                {
                    zitem.SubItems.Add(s[z2][z1]);
                }
                zz();
            }
            
        }
        public void zz()
        {
            z.Items.Add(zitem);
        }
    }
}