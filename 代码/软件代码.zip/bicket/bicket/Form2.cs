﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bicket
{
    public partial class Form2 : Form
    {
        Thread th;
        int x;
        public Form2()
        {
            InitializeComponent();
            this.Show();
          
        }
        public void a(String s, int a)
        {
            try
            {

                label1.Text = s;
                this.Show();
                 x = a;
                 timer1.Interval = x * 10;
                 timer1.Tick += new EventHandler(objtmr_Tick);
                 timer1.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void objtmr_Tick(object sender, EventArgs e)
        {
            try
            {
               // progressBar1.Value = progressBar1.Value+1;
                progressBar1.PerformStep();
                if (progressBar1.Value == 100)
                {
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
